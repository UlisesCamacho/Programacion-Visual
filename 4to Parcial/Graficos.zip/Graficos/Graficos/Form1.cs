﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Graficos
{
    public partial class Form1 : Form
    {
        List<Figura> lf;

        public Form1()
        {
            InitializeComponent();
            lf = new List<Figura>();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            foreach (Figura f in lf)
            {
                if (f.dir == 1)
                { f.x += 10; }
                else
                { f.x -= 10; }

                if (f.x > this.Bounds.Width-40)
                { f.dir = 0; }
                if (f.x < 0)
                { f.dir = 1; }

            }
            this.Invalidate();
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            Figura f = new Figura();
            f.x = e.X;
            f.y = e.Y;
            f.dir = 1;
            lf.Add(f);
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = this.CreateGraphics();
            foreach (Figura f in lf)
            {
                g.DrawEllipse(new Pen(Color.Blue), f.x, f.y, 20, 20);
            }
        }
    }
}
