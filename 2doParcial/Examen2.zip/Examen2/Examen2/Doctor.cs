﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen2
{
    public class Doctor
    {
        public String NombreDoc { get; set; }
        public int CedulaDoc { get; set; }

        public Doctor() { }
    }
}
